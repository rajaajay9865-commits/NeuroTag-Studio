import math
from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from .database import get_db
from .models import Note, Tag, NoteTag
from .schemas import KnowledgeGraphResponse, GraphNode, GraphLink

router = APIRouter(prefix="/graph", tags=["Knowledge Graph"])

@router.get("", response_model=KnowledgeGraphResponse)
async def get_knowledge_graph(
    domain: Optional[str] = Query("All"),
    db: AsyncSession = Depends(get_db)
):
    """
    Computes 2D radial/network graph nodes and links from Note-to-Tag relationships.
    """
    stmt = select(Note).options(selectinload(Note.note_tags).selectinload(NoteTag.tag))
    if domain and domain != "All":
        stmt = stmt.where(Note.academic_domain == domain)

    res = await db.execute(stmt)
    notes = res.scalars().all()

    nodes = []
    links = []
    center_x = 420.0
    center_y = 260.0

    # Inner Ring: Notes
    for idx, note in enumerate(notes):
        angle = (idx / max(len(notes), 1)) * 2 * math.pi
        radius = 115.0
        nodes.append(GraphNode(
            id=f"note-{note.note_id}",
            rawId=note.note_id,
            label=note.title[:22] + "..." if len(note.title) > 22 else note.title,
            fullTitle=note.title,
            type="note",
            domain=note.academic_domain,
            x=round(center_x + radius * math.cos(angle), 1),
            y=round(center_y + radius * math.sin(angle), 1)
        ))

    # Outer Ring: Unique Tags connected to these notes
    tags_stmt = select(Tag).options(selectinload(Tag.note_tags))
    tag_res = await db.execute(tags_stmt)
    all_tags = tag_res.scalars().all()

    tag_idx = 0
    for tag in all_tags:
        # Check if connected to any visible note
        connected_notes = [nt.note_id for nt in tag.note_tags if any(n.note_id == nt.note_id for n in notes)]
        if connected_notes:
            angle = (tag_idx / max(len(all_tags), 1)) * 2 * math.pi + 0.25
            radius = 215.0
            tag_node_id = f"tag-{tag.tag_name}"

            # Calculate avg confidence
            scores = [nt.confidence_score for nt in tag.note_tags if nt.note_id in connected_notes]
            avg_conf = round(sum(scores) / max(len(scores), 1), 1)

            nodes.append(GraphNode(
                id=tag_node_id,
                rawId=tag.tag_name,
                label=tag.tag_name,
                type="tag",
                category=tag.tag_category,
                confidence=avg_conf,
                count=len(connected_notes),
                x=round(center_x + radius * math.cos(angle), 1),
                y=round(center_y + radius * math.sin(angle), 1)
            ))

            for n_id in connected_notes:
                links.append(GraphLink(
                    source=f"note-{n_id}",
                    target=tag_node_id
                ))
            tag_idx += 1

    return KnowledgeGraphResponse(nodes=nodes, links=links)
