import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from sqlalchemy.orm import selectinload

from .database import get_db
from .models import Note, Tag, NoteTag
from .schemas import NoteCreateRequest, NoteUpdateRequest, NoteResponse, TagItem, NamedEntityItem
from .nlp_service import NLPTaggingService

router = APIRouter(prefix="/notes", tags=["Notes & NLP"])

@router.post("/analyze", response_model=NoteResponse)
async def analyze_and_create_note(
    req: NoteCreateRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Extracts tags, NER entities, domain taxonomy, and Bloom classification,
    then saves Note, Tags, and NoteTag mappings transactionally into MySQL/SQLite.
    """
    # 1. Run NLP pipeline
    nlp_data = await NLPTaggingService.analyze_note(
        title=req.title,
        course_code=req.courseCode or "CS-101",
        content=req.rawContent,
        pipeline=req.pipeline or "Zero-Shot LLM (Gemini)"
    )

    note_id = f"note-{uuid.uuid4().hex[:12]}"

    # 2. Instantiate Note
    new_note = Note(
        note_id=note_id,
        title=req.title,
        course_code=req.courseCode,
        academic_domain=nlp_data.get("primaryDomain", "Computer Science"),
        sub_domain=nlp_data.get("subDomain", "General"),
        bloom_taxonomy=nlp_data.get("bloomsLevel", "Analyze"),
        difficulty=nlp_data.get("difficulty", "Intermediate"),
        nlp_pipeline=req.pipeline,
        raw_content=req.rawContent,
        summary=nlp_data.get("summary", []),
        entities=nlp_data.get("entities", [])
    )
    db.add(new_note)

    # 3. Create or update Tags and NoteTag relations
    created_tags = []
    for tag_data in nlp_data.get("tags", []):
        tag_name = tag_data["name"]
        
        # Check if Tag exists
        stmt = select(Tag).where(Tag.tag_name == tag_name)
        res = await db.execute(stmt)
        existing_tag = res.scalar_one_or_none()

        if not existing_tag:
            existing_tag = Tag(
                tag_name=tag_name,
                tag_category=tag_data.get("category", "Core Concept"),
                taxonomy_path=tag_data.get("taxonomyPath")
            )
            db.add(existing_tag)
            await db.flush()

        # Add NoteTag association
        note_tag = NoteTag(
            note_id=note_id,
            tag_name=tag_name,
            confidence_score=float(tag_data.get("confidence", 85.0))
        )
        db.add(note_tag)

        created_tags.append(TagItem(
            name=tag_name,
            confidence=float(tag_data.get("confidence", 85.0)),
            category=tag_data.get("category", "Core Concept"),
            taxonomyPath=tag_data.get("taxonomyPath")
        ))

    await db.commit()

    return NoteResponse(
        id=new_note.note_id,
        title=new_note.title,
        courseCode=new_note.course_code,
        domain=new_note.academic_domain,
        subDomain=new_note.sub_domain,
        bloomLevel=new_note.bloom_taxonomy,
        difficulty=new_note.difficulty,
        pipelineUsed=new_note.nlp_pipeline,
        content=new_note.raw_content,
        summary=new_note.summary,
        tags=created_tags,
        entities=[NamedEntityItem(**e) for e in new_note.entities],
        updatedAt=str(new_note.updated_at)
    )

@router.get("", response_model=List[NoteResponse])
async def list_notes(
    query: Optional[str] = Query(None),
    domain: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """
    Returns all indexed notes with joined tag associations and confidence weights.
    """
    stmt = select(Note).options(selectinload(Note.note_tags).selectinload(NoteTag.tag))
    
    if query:
        stmt = stmt.where(Note.title.ilike(f"%{query}%") | Note.raw_content.ilike(f"%{query}%"))
    if domain and domain != "All":
        stmt = stmt.where(Note.academic_domain == domain)

    res = await db.execute(stmt)
    notes = res.scalars().all()

    output = []
    for n in notes:
        tag_items = [
            TagItem(
                name=nt.tag_name,
                confidence=nt.confidence_score,
                category=nt.tag.tag_category if nt.tag else "Core Concept",
                taxonomyPath=nt.tag.taxonomy_path if nt.tag else None
            )
            for nt in n.note_tags
        ]
        output.append(NoteResponse(
            id=n.note_id,
            title=n.title,
            courseCode=n.course_code,
            domain=n.academic_domain,
            subDomain=n.sub_domain,
            bloomLevel=n.bloom_taxonomy,
            difficulty=n.difficulty,
            pipelineUsed=n.nlp_pipeline,
            content=n.raw_content,
            summary=n.summary or [],
            tags=tag_items,
            entities=[NamedEntityItem(**e) for e in (n.entities or [])],
            updatedAt=str(n.updated_at)
        ))
    return output

@router.delete("/{note_id}")
async def delete_note(note_id: str, db: AsyncSession = Depends(get_db)):
    stmt = select(Note).where(Note.note_id == note_id)
    res = await db.execute(stmt)
    note = res.scalar_one_or_none()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")

    await db.delete(note)
    await db.commit()
    return {"message": "Note deleted successfully", "id": note_id}
