from typing import List, Optional
from pydantic import BaseModel, Field

class TagItem(BaseModel):
    name: str = Field(..., description="Canonical academic concept or keyword")
    confidence: float = Field(..., ge=0.0, le=100.0, description="Confidence percentage (0-100)")
    category: str = Field(default="Core Concept", description="Core Concept | Tool/Tech | Prerequisite | Action Item")
    taxonomyPath: Optional[str] = Field(None, description="Hierarchical breadcrumb: Domain > Discipline > Concept")

class NamedEntityItem(BaseModel):
    text: str = Field(..., description="Exact entity text detected from note")
    type: str = Field(default="Concept", description="Concept | Algorithm | Tool | Metric")

class NoteCreateRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=255)
    courseCode: Optional[str] = "CS-101"
    rawContent: str = Field(..., min_length=5)
    pipeline: Optional[str] = "Zero-Shot LLM (Gemini)"

class NoteUpdateRequest(BaseModel):
    title: Optional[str] = None
    courseCode: Optional[str] = None
    academicDomain: Optional[str] = None
    subDomain: Optional[str] = None
    rawContent: Optional[str] = None
    tags: Optional[List[TagItem]] = None

class NoteResponse(BaseModel):
    id: str
    title: str
    courseCode: Optional[str]
    domain: Optional[str]
    subDomain: Optional[str]
    bloomLevel: Optional[str]
    difficulty: Optional[str]
    pipelineUsed: Optional[str]
    content: str
    summary: List[str]
    tags: List[TagItem]
    entities: List[NamedEntityItem]
    updatedAt: Optional[str]

    class Config:
        from_attributes = True

class GraphNode(BaseModel):
    id: str
    rawId: str
    label: str
    fullTitle: Optional[str] = None
    type: str  # 'note' | 'tag'
    domain: Optional[str] = None
    category: Optional[str] = None
    confidence: Optional[float] = None
    count: Optional[int] = None
    x: Optional[float] = None
    y: Optional[float] = None

class GraphLink(BaseModel):
    source: str
    target: str

class KnowledgeGraphResponse(BaseModel):
    nodes: List[GraphNode]
    links: List[GraphLink]

class FlashcardItem(BaseModel):
    id: str
    tag: str
    question: str
    answer: str
    difficulty: str

class QuizOptionItem(BaseModel):
    question: str
    options: List[str]
    correctIndex: int
    explanation: str

class StudyMaterialResponse(BaseModel):
    flashcards: List[FlashcardItem]
    quiz: List[QuizOptionItem]
