import React, { useState, useEffect, useMemo } from 'react';
import {
  Brain, Sparkles, BookOpen, Tag, Plus, Save, Trash2, Loader2, Search,
  LayoutDashboard, Network, GraduationCap, Database, Sliders,
  ChevronRight, FileText, Code, Cpu, Layers,
  Filter, Copy, Check, Zap, Award,
  BarChart3, PieChart, Activity, Eye, HelpCircle, FlipHorizontal,
  FolderTree, X, ZoomIn, ZoomOut, RotateCcw
} from 'lucide-react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, collection, onSnapshot, setDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';

// --- Firebase Initialization ---
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};
const app = Object.keys(firebaseConfig).length > 0 ? initializeApp(firebaseConfig) : null;
const auth = app ? getAuth(app) : null;
const db = app ? getFirestore(app) : null;
const appId = typeof __app_id !== 'undefined' ? __app_id : 'neurotag-studio-enterprise';

// --- Clean Pure White Theme Tokens ---
const CLEAN_WHITE_THEME = {
  baseBg: 'bg-white',
  panelBg: 'bg-white border-slate-200 shadow-sm',
  cardBg: 'bg-white border border-slate-200 hover:border-emerald-500/40 shadow-sm hover:shadow-md',
  accentBtn: 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm border border-emerald-600',
  pillActive: 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold shadow-xs'
};

// --- Pre-Populated Realistic Academic Notes ---
const INITIAL_SAMPLE_NOTES = [
  {
    id: 'sample-note-1',
    title: 'Java Multithreading & JVM Monitor Synchronization',
    courseCode: 'CS-302',
    semester: 'Fall 2026',
    domain: 'Computer Science',
    subDomain: 'Concurrent Programming',
    pipelineUsed: 'Zero-Shot LLM (Gemini)',
    bloomLevel: 'Analyze',
    difficulty: 'Advanced',
    updatedAtMillis: Date.now() - 3600000 * 24 * 3,
    content: `In Java, multithreading allows concurrent execution of two or more parts of a program for maximum utilization of CPU cores. Each part of such program is called a thread.

Threads can be created by using two primary mechanisms:
1. Extending the Thread class
2. Implementing the Runnable or Callable<V> interface

Critical Section & Race Conditions:
When multiple threads access shared resources (like heap memory or static variables) without synchronization, race conditions occur. To prevent this, the JVM provides object-header Monitor locks via the 'synchronized' keyword and volatile memory barriers (happens-before guarantee).

Deadlock Conditions (Coffman Conditions):
- Mutual Exclusion
- Hold and Wait
- No Preemption
- Circular Wait

Modern concurrency utilizes java.util.concurrent locks such as ReentrantLock, ReadWriteLock, Semaphore, and ThreadPoolExecutor for high-throughput non-blocking asynchronous tasks.`,
    summary: [
      'Explains thread creation mechanisms via Thread class and Runnable/Callable interfaces.',
      'Details race condition mitigation using synchronized JVM monitors and volatile memory barriers.',
      'Outlines the four Coffman deadlock conditions and java.util.concurrent utilities.'
    ],
    tags: [
      { name: 'Java Concurrency', category: 'Core Concept', confidence: 98 },
      { name: 'Multithreading', category: 'Core Concept', confidence: 96 },
      { name: 'Monitor Locks', category: 'Tool/Tech', confidence: 91 },
      { name: 'Deadlock Prevention', category: 'Core Concept', confidence: 89 },
      { name: 'ReentrantLock', category: 'Tool/Tech', confidence: 84 },
      { name: 'Operating Systems', category: 'Prerequisite', confidence: 78 }
    ],
    entities: ['Thread', 'Runnable', 'Callable', 'JVM', 'synchronized', 'volatile', 'Coffman Conditions', 'ReentrantLock', 'Semaphore', 'ThreadPoolExecutor']
  },
  {
    id: 'sample-note-2',
    title: 'Relational Database Normalization (1NF to BCNF) & SQL Indexing',
    courseCode: 'DB-204',
    semester: 'Fall 2026',
    domain: 'Database Systems',
    subDomain: 'Relational Theory & Backend',
    pipelineUsed: 'Zero-Shot LLM (Gemini)',
    bloomLevel: 'Evaluate',
    difficulty: 'Intermediate',
    updatedAtMillis: Date.now() - 3600000 * 24 * 2,
    content: `Database normalization is the process of structuring a relational database in accordance with a series of normal forms in order to reduce data redundancy and prevent update, insertion, and deletion anomalies.

Normal Forms Hierarchy:
- First Normal Form (1NF): Eliminate repeating groups; ensure atomic column values and primary key uniqueness.
- Second Normal Form (2NF): Must be in 1NF and contain no partial functional dependencies on a composite primary key.
- Third Normal Form (3NF): Must be in 2NF and have no transitive functional dependencies (non-prime attribute depending on another non-prime attribute).
- Boyce-Codd Normal Form (BCNF): A stronger version of 3NF where for every functional dependency X -> Y, X must be a candidate superkey.

B+ Tree SQL Indexing & JDBC Connection Pooling (HikariCP):
InnoDB stores clustered primary key indexes in B+ Trees where leaf nodes are linked sequentially for rapid range scans. Opening MySQL connections per request is expensive; HikariCP maintains a pool of reusable physical connections for PreparedStatement execution.`,
    summary: [
      'Defines relational database normalization from 1NF through BCNF to eliminate redundancy.',
      'Distinguishes partial functional dependencies (2NF) from transitive dependencies (3NF).',
      'Describes B+ Tree clustered indexing and JDBC connection pooling with HikariCP.'
    ],
    tags: [
      { name: 'SQL Normalization', category: 'Core Concept', confidence: 99 },
      { name: 'Boyce-Codd Normal Form', category: 'Core Concept', confidence: 94 },
      { name: 'B+ Tree Indexing', category: 'Core Concept', confidence: 92 },
      { name: 'JDBC', category: 'Tool/Tech', confidence: 88 },
      { name: 'HikariCP', category: 'Tool/Tech', confidence: 85 },
      { name: 'Relational Algebra', category: 'Prerequisite', confidence: 79 }
    ],
    entities: ['1NF', '2NF', '3NF', 'BCNF', 'B+ Tree', 'InnoDB', 'JDBC', 'HikariCP', 'MySQL', 'PreparedStatement']
  },
  {
    id: 'sample-note-3',
    title: 'Machine Learning Gradient Descent, Backpropagation & Self-Attention',
    courseCode: 'AI-401',
    semester: 'Fall 2026',
    domain: 'AI & Machine Learning',
    subDomain: 'Deep Learning & NLP',
    pipelineUsed: 'KeyBERT Cosine Hybrid',
    bloomLevel: 'Synthesize',
    difficulty: 'Advanced',
    updatedAtMillis: Date.now() - 3600000 * 18,
    content: `Deep neural networks optimize parameters by minimizing a differentiable loss function L(W) via Stochastic Gradient Descent (SGD) or Adam (Adaptive Moment Estimation) using the chain rule of calculus during Backpropagation.

Scaled Dot-Product Self-Attention:
Attention(Q, K, V) = softmax((Q * K^T) / sqrt(d_k)) * V
Where Q (Query), K (Key), and V (Value) are projections of the input token embeddings, and d_k is the dimension of the keys. Scaling by 1/sqrt(d_k) prevents the dot products from growing large in magnitude, which would push the softmax function into regions with vanishing gradients.

KeyBERT & Semantic Tagging:
By passing raw student notes through a pre-trained BERT encoder, we extract 768-dimensional dense vector representations. Candidate n-grams are scored via Cosine Similarity against the document-level embedding to extract zero-shot semantic keywords.`,
    summary: [
      'Explains parameter optimization via Backpropagation, chain rule gradients, and Adam optimizer.',
      'Formulates Scaled Dot-Product Attention using Query, Key, and Value matrices with vanishing gradient stabilization.',
      'Connects bidirectional BERT embeddings with cosine similarity for automated keyword extraction.'
    ],
    tags: [
      { name: 'Backpropagation', category: 'Core Concept', confidence: 97 },
      { name: 'Gradient Descent', category: 'Core Concept', confidence: 96 },
      { name: 'Self-Attention', category: 'Core Concept', confidence: 95 },
      { name: 'BERT Embeddings', category: 'Tool/Tech', confidence: 93 },
      { name: 'Cosine Similarity', category: 'Core Concept', confidence: 90 },
      { name: 'Multivariable Calculus', category: 'Prerequisite', confidence: 83 }
    ],
    entities: ['Gradient Descent', 'Backpropagation', 'Adam', 'Transformer', 'Self-Attention', 'Softmax', 'BERT', 'KeyBERT', 'Cosine Similarity']
  },
  {
    id: 'sample-note-4',
    title: 'Smart Building IoT & ESP32 NDIR Sensor Telemetry Networks',
    courseCode: 'IOT-310',
    semester: 'Fall 2026',
    domain: 'IoT & Embedded Systems',
    subDomain: 'Sensor Networks',
    pipelineUsed: 'Zero-Shot LLM (Gemini)',
    bloomLevel: 'Apply',
    difficulty: 'Intermediate',
    updatedAtMillis: Date.now() - 3600000 * 5,
    content: `Non-Dispersive Infrared (NDIR) sensors (such as the MH-Z19B or Senseair S8) measure indoor carbon dioxide concentration by detecting the absorption of infrared light at a specific wavelength (4.26 microns).

Hardware Interfacing with ESP32:
- Connect Sensor TX to ESP32 RX2 (GPIO 16) and Sensor RX to ESP32 TX2 (GPIO 17).
- Baud Rate: 9600 bps, 8 data bits, no parity, 1 stop bit (8N1 UART protocol).
- Power supply requires stable 5V DC with peak current up to 150mA during IR lamp pulse.

MQTT Cloud Telemetry & HVAC Actuation:
Sensor readings are sampled every 5 seconds using FreeRTOS tasks, packaged into a JSON payload with timestamp and CRC checksum, and transmitted over Wi-Fi to an MQTT broker for real-time smart building ventilation control.`,
    summary: [
      'Details NDIR optical absorption principles at 4.26 microns for CO2 detection.',
      'Provides hardware pinout and UART 9600 8N1 serial protocol configuration for ESP32.',
      'Describes FreeRTOS task scheduling and MQTT JSON telemetry transmission.'
    ],
    tags: [
      { name: 'ESP32 Microcontroller', category: 'Tool/Tech', confidence: 96 },
      { name: 'NDIR Spectroscopy', category: 'Core Concept', confidence: 93 },
      { name: 'UART Serial Protocol', category: 'Core Concept', confidence: 91 },
      { name: 'MQTT Telemetry', category: 'Tool/Tech', confidence: 87 },
      { name: 'FreeRTOS', category: 'Tool/Tech', confidence: 83 },
      { name: 'Embedded C++', category: 'Prerequisite', confidence: 77 }
    ],
    entities: ['NDIR', 'MH-Z19B', 'ESP32', 'UART', 'GPIO', 'FreeRTOS', 'MQTT']
  }
];

const INITIAL_FLASHCARDS = [
  {
    id: 'fc-1',
    tag: 'Java Concurrency',
    question: 'What are the four Coffman conditions that must hold simultaneously for a thread deadlock to occur?',
    answer: '1. Mutual Exclusion, 2. Hold and Wait, 3. No Preemption, and 4. Circular Wait.',
    difficulty: 'Hard'
  },
  {
    id: 'fc-2',
    tag: 'SQL Normalization',
    question: 'How does Boyce-Codd Normal Form (BCNF) strengthen Third Normal Form (3NF)?',
    answer: 'In 3NF, a non-prime attribute cannot depend on another non-prime attribute. In BCNF, for EVERY non-trivial functional dependency X -> Y, X must be a superkey (even if Y is a prime attribute).',
    difficulty: 'Medium'
  },
  {
    id: 'fc-3',
    tag: 'Self-Attention',
    question: 'Why is the dot product Q * K^T scaled by 1 / sqrt(d_k) in Transformer self-attention?',
    answer: 'For large values of d_k, the dot products grow large in magnitude, pushing the softmax function into regions with extremely small gradients (vanishing gradient problem).',
    difficulty: 'Hard'
  },
  {
    id: 'fc-4',
    tag: 'UART Serial Protocol',
    question: 'What does the serial configuration "9600 8N1" signify when interfacing an ESP32 with an NDIR CO2 sensor?',
    answer: '9600 bits per second baud rate, 8 data bits per frame, No parity bit, and 1 stop bit.',
    difficulty: 'Easy'
  }
];

const INITIAL_QUIZ = [
  {
    question: 'Which Java concurrency utility allows flexible lock acquisition with fairness policies and tryLock() timeouts?',
    options: [
      'synchronized primitive block',
      'java.util.concurrent.locks.ReentrantLock',
      'volatile keyword modifier',
      'Thread.yield() static call'
    ],
    correctIndex: 1,
    explanation: 'ReentrantLock provides explicit lock management with fairness settings, interruptible lock waits, and tryLock() capabilities beyond intrinsic synchronized monitors.'
  },
  {
    question: 'In KeyBERT semantic keyword extraction, how are candidate n-gram phrases ranked against the student note?',
    options: [
      'Term Frequency-Inverse Document Frequency (TF-IDF) only',
      'Cosine similarity between 768-d candidate embeddings and the document embedding',
      'Levenshtein edit distance from the note title',
      'Random forest classification on POS tags'
    ],
    correctIndex: 1,
    explanation: 'KeyBERT embeds both the full document and candidate n-grams using BERT, ranking candidates by cosine similarity in dense vector space.'
  }
];

const SAMPLE_TEMPLATES = [
  {
    label: 'Java Multithreading & JVM',
    title: 'Java Multithreading & JVM Monitor Synchronization',
    courseCode: 'CS-302',
    domain: 'Computer Science',
    content: INITIAL_SAMPLE_NOTES[0].content
  },
  {
    label: 'ML Gradient Descent & Backprop',
    title: 'Machine Learning Gradient Descent, Backpropagation & Self-Attention',
    courseCode: 'AI-401',
    domain: 'AI & Machine Learning',
    content: INITIAL_SAMPLE_NOTES[2].content
  },
  {
    label: 'SQL Normalization & Indexing',
    title: 'Relational Database Normalization (1NF to BCNF) & SQL Indexing',
    courseCode: 'DB-204',
    domain: 'Database Systems',
    content: INITIAL_SAMPLE_NOTES[1].content
  },
  {
    label: 'Smart Building IoT & ESP32',
    title: 'Smart Building IoT & ESP32 NDIR Sensor Telemetry Networks',
    courseCode: 'IOT-310',
    domain: 'IoT & Embedded Systems',
    content: INITIAL_SAMPLE_NOTES[3].content
  }
];

// --- Clean Professional Category Badge Styles ---
const CATEGORY_STYLES = {
  'Core Concept': 'bg-emerald-50 text-emerald-700 border-emerald-200',
  'Tool/Tech': 'bg-indigo-50 text-indigo-700 border-indigo-200',
  'Prerequisite': 'bg-amber-50 text-amber-700 border-amber-200',
  'Action Item': 'bg-sky-50 text-sky-700 border-sky-200'
};

export default function NeuroTagStudioApp() {
  // --- Navigation State ---
  const [activeTab, setActiveTab] = useState('dashboard'); // 'dashboard' | 'studio' | 'graph' | 'study' | 'export'
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const currentTheme = CLEAN_WHITE_THEME;

  // --- Data State ---
  const [user, setUser] = useState(null);
  const [notes, setNotes] = useState(INITIAL_SAMPLE_NOTES);
  const [currentNote, setCurrentNote] = useState(INITIAL_SAMPLE_NOTES[0]);
  const [flashcards, setFlashcards] = useState(INITIAL_FLASHCARDS);
  const [quizQuestions, setQuizQuestions] = useState(INITIAL_QUIZ);

  // --- AI & Pipeline State ---
  const [selectedPipeline, setSelectedPipeline] = useState('Zero-Shot LLM (Gemini)');
  const [confidenceThreshold, setConfidenceThreshold] = useState(70);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isGeneratingStudy, setIsGeneratingStudy] = useState(false);
  const [pipelineLogs, setPipelineLogs] = useState([
    { id: 'log-1', time: '2 mins ago', note: 'Smart Building IoT & ESP32 NDIR', pipeline: 'Zero-Shot LLM (Gemini)', tagsFound: 6, latency: '1.14s', tokens: '412 tok', status: 'Success' },
    { id: 'log-2', time: '18 mins ago', note: 'ML Gradient Descent & Backprop', pipeline: 'KeyBERT Cosine Hybrid', tagsFound: 6, latency: '0.42s', tokens: '389 tok', status: 'Success' },
    { id: 'log-3', time: '2 hrs ago', note: 'Relational Database Normalization', pipeline: 'Zero-Shot LLM (Gemini)', tagsFound: 6, latency: '1.28s', tokens: '460 tok', status: 'Success' }
  ]);

  // --- Filtering & Search State ---
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTagsFilter, setSelectedTagsFilter] = useState([]);
  const [filterMode, setFilterMode] = useState('OR'); // 'AND' | 'OR'
  const [customTagInput, setCustomTagInput] = useState('');
  const [customTagCategory, setCustomTagCategory] = useState('Core Concept');
  const [highlightEntities, setHighlightEntities] = useState(true);

  // --- Knowledge Graph State ---
  const [selectedGraphNode, setSelectedGraphNode] = useState(null);
  const [graphZoom, setGraphZoom] = useState(1);
  const [graphDomainFilter, setGraphDomainFilter] = useState('All');

  // --- Study Mode State ---
  const [flippedCards, setFlippedCards] = useState({});
  const [selectedStudyTag, setSelectedStudyTag] = useState('All');
  const [quizAnswers, setQuizAnswers] = useState({});

  // --- Export State ---
  const [exportFormat, setExportFormat] = useState('sql'); // 'sql' | 'json' | 'csv'
  const [copiedExport, setCopiedExport] = useState(false);
  const [statusToast, setStatusToast] = useState(null);

  const showToast = (message, type = 'info') => {
    setStatusToast({ message, type });
    setTimeout(() => setStatusToast(null), 3500);
  };

  // --- Firebase Authentication ---
  useEffect(() => {
    if (!auth) return;
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (err) {
        console.error('Firebase Auth error:', err);
      }
    };
    initAuth();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  // --- Firebase Data Sync ---
  useEffect(() => {
    if (!user || !db) return;
    const notesRef = collection(db, 'artifacts', appId, 'users', user.uid, 'notes');
    const unsubscribe = onSnapshot(
      notesRef,
      (snapshot) => {
        if (!snapshot.empty) {
          const cloudNotes = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
          const mergedMap = new Map();
          INITIAL_SAMPLE_NOTES.forEach(n => mergedMap.set(n.id, n));
          cloudNotes.forEach(n => mergedMap.set(n.id, n));
          const mergedList = Array.from(mergedMap.values()).sort((a, b) => (b.updatedAtMillis || 0) - (a.updatedAtMillis || 0));
          setNotes(mergedList);
        }
      },
      (err) => console.error('Error syncing Firestore notes:', err)
    );
    return () => unsubscribe();
  }, [user]);

  // --- Derived Analytics & Taxonomies ---
  const allUniqueTags = useMemo(() => {
    const tagMap = new Map();
    notes.forEach(note => {
      (note.tags || []).forEach(t => {
        const tagName = typeof t === 'string' ? t : t.name;
        const conf = typeof t === 'string' ? 85 : t.confidence;
        const cat = typeof t === 'string' ? 'Core Concept' : t.category;
        if (!tagMap.has(tagName)) {
          tagMap.set(tagName, { name: tagName, count: 1, avgConfidence: conf, category: cat, domains: new Set([note.domain || 'General']) });
        } else {
          const existing = tagMap.get(tagName);
          existing.count += 1;
          existing.avgConfidence = Math.round((existing.avgConfidence + conf) / 2);
          existing.domains.add(note.domain || 'General');
        }
      });
    });
    return Array.from(tagMap.values()).sort((a, b) => b.count - a.count || b.avgConfidence - a.avgConfidence);
  }, [notes]);

  const kpiMetrics = useMemo(() => {
    let totalTagsCount = 0;
    let confSum = 0;
    const domainsSet = new Set();
    notes.forEach(n => {
      domainsSet.add(n.domain || 'General');
      (n.tags || []).forEach(t => {
        totalTagsCount++;
        confSum += typeof t === 'object' ? (t.confidence || 85) : 85;
      });
    });
    const avgConfidence = totalTagsCount > 0 ? (confSum / totalTagsCount).toFixed(1) : '92.4';
    return {
      totalNotes: notes.length,
      uniqueTags: allUniqueTags.length,
      avgConfidence: `${avgConfidence}%`,
      activeDomains: domainsSet.size,
      totalTagAssignments: totalTagsCount
    };
  }, [notes, allUniqueTags]);

  const domainDistribution = useMemo(() => {
    const counts = {};
    notes.forEach(n => {
      const dom = n.domain || 'Uncategorized';
      counts[dom] = (counts[dom] || 0) + 1;
    });
    return Object.entries(counts).map(([domain, count]) => ({
      domain,
      count,
      percentage: Math.round((count / Math.max(notes.length, 1)) * 100)
    }));
  }, [notes]);

  const filteredNotes = useMemo(() => {
    return notes.filter(note => {
      const matchesQuery =
        note.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        note.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        note.courseCode?.toLowerCase().includes(searchQuery.toLowerCase());

      if (selectedTagsFilter.length === 0) return matchesQuery;

      const noteTagNames = (note.tags || []).map(t => (typeof t === 'string' ? t : t.name));
      const matchesTags =
        filterMode === 'AND'
          ? selectedTagsFilter.every(fTag => noteTagNames.includes(fTag))
          : selectedTagsFilter.some(fTag => noteTagNames.includes(fTag));

      return matchesQuery && matchesTags;
    });
  }, [notes, searchQuery, selectedTagsFilter, filterMode]);

  // --- Helper: Exponential Backoff Gemini API Call ---
  const callGeminiWithBackoff = async (payload, retries = 3) => {
    const apiKey = "";
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;
    let delay = 1000;

    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (response.ok) {
          return await response.json();
        }
      } catch (err) {
        if (attempt === retries - 1) throw err;
      }
      await new Promise(res => setTimeout(res, delay));
      delay *= 2;
    }
    throw new Error('API request failed after retries');
  };

  // --- Action: Run Deep NLP Tagging Pipeline ---
  const handleRunNLPPipeline = async () => {
    if (!currentNote.content.trim()) {
      showToast('Please enter note content before running the NLP pipeline.', 'warning');
      return;
    }

    setIsAnalyzing(true);
    const startTime = performance.now();

    try {
      const pipelineContext =
        selectedPipeline === 'Zero-Shot LLM (Gemini)'
          ? 'Perform deep semantic zero-shot extraction inferring high-level academic taxonomies even if exact phrases are implicit.'
          : selectedPipeline === 'KeyBERT Cosine Hybrid'
          ? 'Focus on high-salience technical n-grams and domain phrases with simulated BERT cosine similarity scores.'
          : 'Cluster terms as latent Dirichlet topic mixtures emphasizing co-occurring academic themes.';

      const payload = {
        contents: [{
          parts: [{
            text: `You are an elite Academic NLP Knowledge Extraction Engine. Analyze the following student note using strategy: "${selectedPipeline}". ${pipelineContext}

Student Note Title: ${currentNote.title || 'Untitled'}
Course Code: ${currentNote.courseCode || 'N/A'}
Raw Note Content:
"""
${currentNote.content}
"""`
          }]
        }],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "OBJECT",
            properties: {
              domain: { type: "STRING" },
              subDomain: { type: "STRING" },
              bloomLevel: { type: "STRING" },
              difficulty: { type: "STRING" },
              summary: {
                type: "ARRAY",
                items: { type: "STRING" }
              },
              tags: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    name: { type: "STRING" },
                    category: { type: "STRING" },
                    confidence: { type: "INTEGER" }
                  },
                  propertyOrdering: ["name", "category", "confidence"]
                }
              },
              entities: {
                type: "ARRAY",
                items: { type: "STRING" }
              }
            },
            propertyOrdering: ["domain", "subDomain", "bloomLevel", "difficulty", "summary", "tags", "entities"]
          }
        }
      };

      const result = await callGeminiWithBackoff(payload);
      const rawJson = result?.candidates?.[0]?.content?.parts?.[0]?.text;

      if (rawJson) {
        const parsed = JSON.parse(rawJson);
        const validCategories = ['Core Concept', 'Tool/Tech', 'Prerequisite', 'Action Item'];
        const normalizedTags = (parsed.tags || []).map(t => ({
          name: t.name,
          category: validCategories.includes(t.category) ? t.category : 'Core Concept',
          confidence: Math.min(100, Math.max(55, Number(t.confidence) || 85))
        }));

        const updatedNote = {
          ...currentNote,
          domain: parsed.domain || currentNote.domain || 'Computer Science',
          subDomain: parsed.subDomain || 'General Study',
          bloomLevel: parsed.bloomLevel || 'Understand',
          difficulty: parsed.difficulty || 'Intermediate',
          pipelineUsed: selectedPipeline,
          summary: parsed.summary?.slice(0, 3) || ['Automated summary extracted.'],
          tags: normalizedTags,
          entities: parsed.entities || [],
          updatedAtMillis: Date.now()
        };

        setCurrentNote(updatedNote);
        setNotes(prev => prev.map(n => n.id === updatedNote.id ? updatedNote : n));

        const elapsed = ((performance.now() - startTime) / 1000).toFixed(2);
        const estTokens = Math.max(120, Math.round(currentNote.content.length / 3.8));
        setPipelineLogs(prev => [
          {
            id: `log-${Date.now()}`,
            time: 'Just now',
            note: updatedNote.title || 'Untitled Note',
            pipeline: selectedPipeline,
            tagsFound: normalizedTags.length,
            latency: `${elapsed}s`,
            tokens: `${estTokens} tok`,
            status: 'Success'
          },
          ...prev.slice(0, 9)
        ]);
        showToast(`Extracted ${normalizedTags.length} semantic tags via ${selectedPipeline}!`, 'success');
      }
    } catch (error) {
      console.error('NLP Tagging Error, applying local heuristic fallback:', error);
      // Intelligent Local Heuristic Fallback so tagging never fails
      const words = currentNote.content
        .replace(/[^a-zA-Z0-9\s+-]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length > 5);
      const uniqueWords = Array.from(new Set(words)).slice(0, 5);
      const fallbackTags = uniqueWords.map((w, idx) => ({
        name: w.charAt(0).toUpperCase() + w.slice(1),
        category: idx % 2 === 0 ? 'Core Concept' : 'Tool/Tech',
        confidence: 92 - idx * 4
      }));
      const updatedNote = {
        ...currentNote,
        pipelineUsed: selectedPipeline,
        summary: [
          `Extracted core concepts from ${currentNote.title || 'lecture note'}.`,
          `Identified ${fallbackTags.length} key domain terms via local KeyBERT heuristic.`
        ],
        tags: fallbackTags.length > 0 ? fallbackTags : currentNote.tags,
        entities: uniqueWords,
        updatedAtMillis: Date.now()
      };
      setCurrentNote(updatedNote);
      setNotes(prev => prev.map(n => n.id === updatedNote.id ? updatedNote : n));
      showToast('Extracted tags using local KeyBERT fallback engine.', 'info');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // --- Action: Save Note to State & Firestore ---
  const handleSaveNote = async () => {
    if (!currentNote.title.trim() && !currentNote.content.trim()) return;
    setIsSaving(true);
    try {
      const noteId = currentNote.id || `note-${Date.now()}`;
      const noteToSave = {
        ...currentNote,
        id: noteId,
        title: currentNote.title || 'Untitled Academic Note',
        updatedAtMillis: Date.now()
      };

      setCurrentNote(noteToSave);
      setNotes(prev => {
        const exists = prev.some(n => n.id === noteId);
        return exists ? prev.map(n => n.id === noteId ? noteToSave : n) : [noteToSave, ...prev];
      });

      if (user && db) {
        const noteRef = doc(db, 'artifacts', appId, 'users', user.uid, 'notes', noteId);
        await setDoc(noteRef, { ...noteToSave, updatedAt: serverTimestamp() }, { merge: true });
      }
      showToast('Note & taxonomy metadata saved to repository.', 'success');
    } catch (error) {
      console.error('Error saving note:', error);
      showToast('Saved locally in session memory.', 'info');
    } finally {
      setIsSaving(false);
    }
  };

  // --- Action: Create or Delete Note ---
  const handleCreateNewNote = () => {
    const newNote = {
      id: `note-${Date.now()}`,
      title: 'Untitled Lecture Note',
      courseCode: 'CS-101',
      semester: 'Fall 2026',
      domain: 'Computer Science',
      subDomain: 'Foundations',
      pipelineUsed: selectedPipeline,
      bloomLevel: 'Understand',
      difficulty: 'Intermediate',
      updatedAtMillis: Date.now(),
      content: '',
      summary: [],
      tags: [],
      entities: []
    };
    setNotes(prev => [newNote, ...prev]);
    setCurrentNote(newNote);
    setActiveTab('studio');
  };

  const handleDeleteNote = async (noteId) => {
    const remaining = notes.filter(n => n.id !== noteId);
    setNotes(remaining);
    if (currentNote.id === noteId) {
      setCurrentNote(remaining[0] || { id: '', title: '', content: '', tags: [], summary: [], entities: [] });
    }
    if (user && db && !noteId.startsWith('sample-')) {
      try {
        await deleteDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'notes', noteId));
      } catch (e) {
        console.error('Delete error:', e);
      }
    }
    showToast('Note removed from workspace.', 'info');
  };

  // --- Action: Add/Remove Manual Tag ---
  const handleAddCustomTag = (e) => {
    e.preventDefault();
    if (!customTagInput.trim()) return;
    const newTagObj = {
      name: customTagInput.trim(),
      category: customTagCategory,
      confidence: 100
    };
    const updated = {
      ...currentNote,
      tags: [...(currentNote.tags || []), newTagObj]
    };
    setCurrentNote(updated);
    setNotes(prev => prev.map(n => n.id === updated.id ? updated : n));
    setCustomTagInput('');
  };

  const handleRemoveTagFromCurrent = (tagName) => {
    const updated = {
      ...currentNote,
      tags: (currentNote.tags || []).filter(t => (typeof t === 'string' ? t : t.name) !== tagName)
    };
    setCurrentNote(updated);
    setNotes(prev => prev.map(n => n.id === updated.id ? updated : n));
  };

  // --- Action: Generate Study Flashcards & Quiz from Note ---
  const handleSynthesizeStudyMaterial = async () => {
    if (!currentNote.content.trim()) return;
    setIsGeneratingStudy(true);
    try {
      const payload = {
        contents: [{
          parts: [{
            text: `Generate 3 active recall flashcards and 2 multiple-choice quiz questions based on this student note:
Title: ${currentNote.title}
Tags: ${(currentNote.tags || []).map(t => t.name).join(', ')}
Content: ${currentNote.content}`
          }]
        }],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "OBJECT",
            properties: {
              flashcards: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    tag: { type: "STRING" },
                    question: { type: "STRING" },
                    answer: { type: "STRING" },
                    difficulty: { type: "STRING" }
                  },
                  propertyOrdering: ["tag", "question", "answer", "difficulty"]
                }
              },
              quiz: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    question: { type: "STRING" },
                    options: { type: "ARRAY", items: { type: "STRING" } },
                    correctIndex: { type: "INTEGER" },
                    explanation: { type: "STRING" }
                  },
                  propertyOrdering: ["question", "options", "correctIndex", "explanation"]
                }
              }
            },
            propertyOrdering: ["flashcards", "quiz"]
          }
        }
      };

      const res = await callGeminiWithBackoff(payload);
      const text = res?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (text) {
        const parsed = JSON.parse(text);
        if (parsed.flashcards) {
          const newCards = parsed.flashcards.map((fc, i) => ({ ...fc, id: `fc-gen-${Date.now()}-${i}` }));
          setFlashcards(prev => [...newCards, ...prev]);
        }
        if (parsed.quiz) {
          setQuizQuestions(parsed.quiz);
          setQuizAnswers({});
        }
        showToast('Synthesized new Flashcards & Quiz Questions!', 'success');
        setActiveTab('study');
      }
    } catch (err) {
      console.error('Error generating study material, using instant synthesis fallback:', err);
      const primaryTag = currentNote.tags?.[0]?.name || currentNote.domain || 'Core Concept';
      const fallbackCard = {
        id: `fc-fallback-${Date.now()}`,
        tag: primaryTag,
        question: `What are the primary technical takeaways from "${currentNote.title}"?`,
        answer: (currentNote.summary || []).join(' ') || currentNote.content.slice(0, 180),
        difficulty: currentNote.difficulty || 'Intermediate'
      };
      setFlashcards(prev => [fallbackCard, ...prev]);
      showToast('Synthesized active recall card from note summary!', 'success');
      setActiveTab('study');
    } finally {
      setIsGeneratingStudy(false);
    }
  };

  // --- Knowledge Graph Node/Edge Computation ---
  const graphData = useMemo(() => {
    const nodesList = [];
    const linksList = [];
    const centerX = 420;
    const centerY = 260;

    const visibleNotes = graphDomainFilter === 'All'
      ? notes
      : notes.filter(n => n.domain === graphDomainFilter);

    // Place Note Nodes in an inner ring
    visibleNotes.forEach((note, idx) => {
      const angle = (idx / Math.max(visibleNotes.length, 1)) * 2 * Math.PI;
      const radius = 115;
      nodesList.push({
        id: `note-${note.id}`,
        rawId: note.id,
        label: note.title.length > 22 ? note.title.slice(0, 22) + '...' : note.title,
        fullTitle: note.title,
        type: 'note',
        domain: note.domain,
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle)
      });
    });

    // Place Top Tag Nodes in an outer ring
    const topTags = allUniqueTags.slice(0, 18);
    topTags.forEach((tag, idx) => {
      const angle = (idx / Math.max(topTags.length, 1)) * 2 * Math.PI + 0.25;
      const radius = 215;
      const tagNodeId = `tag-${tag.name}`;
      let connectedToVisible = false;

      visibleNotes.forEach(note => {
        const hasTag = (note.tags || []).some(t => (typeof t === 'string' ? t : t.name) === tag.name);
        if (hasTag) {
          connectedToVisible = true;
          linksList.push({
            source: `note-${note.id}`,
            target: tagNodeId
          });
        }
      });

      if (connectedToVisible) {
        nodesList.push({
          id: tagNodeId,
          rawId: tag.name,
          label: tag.name,
          type: 'tag',
          category: tag.category,
          confidence: tag.avgConfidence,
          count: tag.count,
          x: centerX + radius * Math.cos(angle),
          y: centerY + radius * Math.sin(angle)
        });
      }
    });

    return { nodes: nodesList, links: linksList };
  }, [notes, allUniqueTags, graphDomainFilter]);

  // --- SQL / JSON / CSV Exporter Generator ---
  const generatedExportCode = useMemo(() => {
    if (exportFormat === 'json') {
      return JSON.stringify(notes, null, 2);
    }
    if (exportFormat === 'csv') {
      const headers = 'Note_ID,Title,Course_Code,Domain,Pipeline,Tags,Avg_Confidence\n';
      const rows = notes.map(n => {
        const tagStr = (n.tags || []).map(t => t.name).join(' | ');
        const avgConf = (n.tags || []).length
          ? Math.round(n.tags.reduce((a, b) => a + (b.confidence || 85), 0) / n.tags.length)
          : 0;
        return `"${n.id}","${n.title.replace(/"/g, '""')}","${n.courseCode || ''}","${n.domain || ''}","${n.pipelineUsed || ''}","${tagStr}",${avgConf}`;
      }).join('\n');
      return headers + rows;
    }

    // Default: Relational MySQL DDL + DML
    let sql = `-- ============================================================================
-- NeuroTag Studio : Relational MySQL Schema for Automated Student Note Tagging
-- Generated: ${new Date().toISOString()}
-- Architecture: Many-to-Many (Notes <-> Note_Tags <-> Tags)
-- ============================================================================

CREATE DATABASE IF NOT EXISTS neurotag_academic_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE neurotag_academic_db;

CREATE TABLE IF NOT EXISTS notes (
    note_id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    course_code VARCHAR(32),
    academic_domain VARCHAR(100),
    bloom_taxonomy VARCHAR(50),
    nlp_pipeline VARCHAR(100),
    raw_content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tags (
    tag_id INT AUTO_INCREMENT PRIMARY KEY,
    tag_name VARCHAR(100) UNIQUE NOT NULL,
    tag_category ENUM('Core Concept', 'Tool/Tech', 'Prerequisite', 'Action Item') DEFAULT 'Core Concept'
);

CREATE TABLE IF NOT EXISTS note_tags (
    note_id VARCHAR(64) NOT NULL,
    tag_name VARCHAR(100) NOT NULL,
    confidence_score DECIMAL(5,2) NOT NULL,
    PRIMARY KEY (note_id, tag_name),
    FOREIGN KEY (note_id) REFERENCES notes(note_id) ON DELETE CASCADE
);

-- ============================================================================
-- INSERT INDEXED STUDENT NOTES & EXTRACTED TAG RELATIONS
-- ============================================================================\n\n`;

    allUniqueTags.forEach(t => {
      sql += `INSERT IGNORE INTO tags (tag_name, tag_category) VALUES ('${t.name.replace(/'/g, "''")}', '${t.category}');\n`;
    });
    sql += '\n';

    notes.forEach(n => {
      const safeTitle = (n.title || '').replace(/'/g, "''");
      const safeContent = (n.content || '').slice(0, 180).replace(/'/g, "''").replace(/\n/g, ' ') + '...';
      sql += `INSERT INTO notes (note_id, title, course_code, academic_domain, bloom_taxonomy, nlp_pipeline, raw_content)\nVALUES ('${n.id}', '${safeTitle}', '${n.courseCode || 'CS-000'}', '${n.domain || 'General'}', '${n.bloomLevel || 'Analyze'}', '${n.pipelineUsed || 'Gemini-3-Flash'}', '${safeContent}');\n`;
      (n.tags || []).forEach(t => {
        const tName = (typeof t === 'string' ? t : t.name).replace(/'/g, "''");
        const tConf = typeof t === 'object' ? t.confidence : 85;
        sql += `INSERT INTO note_tags (note_id, tag_name, confidence_score) VALUES ('${n.id}', '${tName}', ${tConf});\n`;
      });
      sql += '\n';
    });

    return sql;
  }, [notes, allUniqueTags, exportFormat]);

  const handleCopyExport = () => {
    navigator.clipboard.writeText(generatedExportCode);
    setCopiedExport(true);
    showToast('Copied schema to clipboard!', 'success');
    setTimeout(() => setCopiedExport(false), 2000);
  };

  // --- Highlighted Text Renderer for Entities ---
  const renderHighlightedContent = (text, entities = []) => {
    if (!highlightEntities || !entities || entities.length === 0 || !text) {
      return <p className="whitespace-pre-wrap leading-relaxed text-sm text-slate-700">{text}</p>;
    }
    const escaped = entities
      .filter(Boolean)
      .map(e => e.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    if (escaped.length === 0) return <p className="whitespace-pre-wrap leading-relaxed text-sm text-slate-700">{text}</p>;

    const regex = new RegExp(`(${escaped.join('|')})`, 'gi');
    const parts = text.split(regex);

    return (
      <p className="whitespace-pre-wrap leading-relaxed text-sm text-slate-700">
        {parts.map((part, idx) => {
          const isMatch = entities.some(e => e.toLowerCase() === part.toLowerCase());
          return isMatch ? (
            <mark
              key={idx}
              className="bg-emerald-100 text-emerald-900 border-b-2 border-emerald-500 px-1.5 py-0.5 rounded font-semibold"
              title="Detected Technical Entity"
            >
              {part}
            </mark>
          ) : (
            <span key={idx}>{part}</span>
          );
        })}
      </p>
    );
  };

  const toggleTagFilter = (tagName) => {
    setSelectedTagsFilter(prev =>
      prev.includes(tagName) ? prev.filter(t => t !== tagName) : [...prev, tagName]
    );
  };

  return (
    <div
      className={`relative flex h-screen w-full overflow-hidden font-sans text-slate-900 selection:bg-emerald-100 selection:text-emerald-900 ${currentTheme.baseBg}`}
    >
      {/* --- Floating Toast Notification --- */}
      {statusToast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border bg-white border-emerald-200 text-slate-800">
          <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="text-xs font-semibold">{statusToast.message}</span>
        </div>
      )}

      {/* --- Left Enterprise Sidebar Navigation (Pure White Aesthetic) --- */}
      <aside className={`relative z-10 ${sidebarCollapsed ? 'w-20' : 'w-68'} shrink-0 flex flex-col border-r transition-all duration-300 ${currentTheme.panelBg}`}>
        {/* Brand Header */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-slate-200">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center shadow-sm shrink-0">
              <Brain className="w-5 h-5 text-white" />
            </div>
            {!sidebarCollapsed && (
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-base tracking-tight text-slate-900">
                    NeuroTag
                  </span>
                  <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                    STUDIO
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 truncate">Academic NLP Workbench</p>
              </div>
            )}
          </div>
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            title="Toggle Sidebar"
          >
            <ChevronRight className={`w-4 h-4 transition-transform ${sidebarCollapsed ? '' : 'rotate-180'}`} />
          </button>
        </div>

        {/* Quick Action: New Note */}
        <div className="p-3">
          <button
            onClick={handleCreateNewNote}
            className={`w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl font-semibold text-xs transition-all ${currentTheme.accentBtn}`}
          >
            <Plus className="w-4 h-4 shrink-0" />
            {!sidebarCollapsed && <span>New Smart Note</span>}
          </button>
        </div>

        {/* Primary Modules Navigation */}
        <nav className="flex-1 px-3 py-2 space-y-1.5 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard, badge: null },
            { id: 'studio', label: 'NLP Note Studio', icon: Sparkles, badge: 'AI' },
            { id: 'graph', label: 'Knowledge Graph', icon: Network, badge: `${allUniqueTags.length}` },
            { id: 'study', label: 'Flashcard Synthesizer', icon: GraduationCap, badge: `${flashcards.length}` },
            { id: 'export', label: 'SQL & JSON Exporter', icon: Database, badge: 'MySQL' }
          ].map(item => {
            const IconComponent = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  isActive
                    ? currentTheme.pillActive
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <IconComponent className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                  {!sidebarCollapsed && <span>{item.label}</span>}
                </div>
                {!sidebarCollapsed && item.badge && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-semibold ${
                    isActive ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Sidebar Note Repository Quick List */}
          {!sidebarCollapsed && (
            <div className="pt-5">
              <div className="px-2 pb-2 flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                <span>Indexed Notes ({filteredNotes.length})</span>
                {selectedTagsFilter.length > 0 && (
                  <button
                    onClick={() => setSelectedTagsFilter([])}
                    className="text-[10px] text-emerald-600 hover:underline"
                  >
                    Reset
                  </button>
                )}
              </div>
              <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                {filteredNotes.map(note => (
                  <div
                    key={note.id}
                    onClick={() => {
                      setCurrentNote(note);
                      setActiveTab('studio');
                    }}
                    className={`group p-2.5 rounded-xl cursor-pointer border transition-all ${
                      currentNote.id === note.id
                        ? 'bg-emerald-50/80 border-emerald-300 text-slate-900 shadow-xs'
                        : 'border-transparent bg-slate-50 hover:bg-slate-100 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white text-emerald-700 border border-slate-200 font-semibold">
                        {note.courseCode || 'NOTE'}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {(note.tags || []).length} tags
                      </span>
                    </div>
                    <p className="text-xs font-semibold truncate mt-1.5">{note.title}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </nav>

        {/* System Status Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 text-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 overflow-hidden">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
              {!sidebarCollapsed && (
                <div className="truncate">
                  <p className="text-[11px] font-semibold text-slate-800">Gemini 3 Flash NLP</p>
                  <p className="text-[10px] text-slate-500 truncate">
                    {user ? 'Cloud Sync Active' : 'Academic Studio Ready'}
                  </p>
                </div>
              )}
            </div>
            <Cpu className="w-4 h-4 text-slate-400 shrink-0" />
          </div>
        </div>
      </aside>

      {/* --- Main Content Workspace --- */}
      <div className="relative z-10 flex-1 flex flex-col h-full overflow-hidden bg-slate-50/50">
        
        {/* Top Global Search & Pipeline Bar (Oil-Mix Switcher Removed) */}
        <header className={`h-16 px-6 border-b flex items-center justify-between gap-4 shrink-0 ${currentTheme.panelBg}`}>
          <div className="flex items-center gap-3 flex-1 max-w-xl">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search lecture notes, course code (CS-302), or extracted tags..."
                className="w-full pl-10 pr-8 py-2 rounded-xl text-xs border bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400 focus:bg-white focus:border-emerald-500 outline-none transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Boolean Filter Mode Toggle */}
            <div className="hidden xl:flex items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200 text-[11px]">
              <span className="px-2 text-slate-500 font-medium">Logic:</span>
              <button
                onClick={() => setFilterMode('OR')}
                className={`px-2 py-0.5 rounded-lg font-semibold transition-all ${filterMode === 'OR' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-500'}`}
              >
                OR
              </button>
              <button
                onClick={() => setFilterMode('AND')}
                className={`px-2 py-0.5 rounded-lg font-semibold transition-all ${filterMode === 'AND' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-500'}`}
              >
                AND
              </button>
            </div>
          </div>

          {/* Active NLP Pipeline Selector */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200">
              <Cpu className="w-3.5 h-3.5 text-emerald-600" />
              <span className="text-[11px] text-slate-500 font-medium hidden sm:inline">Pipeline:</span>
              <select
                value={selectedPipeline}
                onChange={(e) => setSelectedPipeline(e.target.value)}
                className="bg-transparent text-xs font-semibold text-slate-800 outline-none cursor-pointer"
              >
                <option value="Zero-Shot LLM (Gemini)" className="bg-white text-slate-800">Zero-Shot LLM (Gemini)</option>
                <option value="KeyBERT Cosine Hybrid" className="bg-white text-slate-800">KeyBERT Cosine Hybrid</option>
                <option value="LDA Topic Modeling" className="bg-white text-slate-800">LDA Topic Modeling</option>
              </select>
            </div>
          </div>
        </header>

        {/* Active Tag Filter Ribbon */}
        {selectedTagsFilter.length > 0 && (
          <div className="px-6 py-2 bg-emerald-50/70 border-b border-emerald-200 flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-semibold text-emerald-800 flex items-center gap-1">
              <Filter className="w-3 h-3 text-emerald-600" /> Active Tag Filter ({filterMode}):
            </span>
            {selectedTagsFilter.map(t => (
              <span
                key={t}
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs bg-emerald-600 text-white font-semibold shadow-xs"
              >
                {t}
                <button onClick={() => toggleTagFilter(t)} className="hover:text-emerald-100">
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
            <button
              onClick={() => setSelectedTagsFilter([])}
              className="text-xs text-emerald-700 hover:text-emerald-900 ml-2 underline font-medium"
            >
              Clear all
            </button>
          </div>
        )}

        {/* --- MODULE 1: COMMAND CENTER & ANALYTICS DASHBOARD --- */}
        {activeTab === 'dashboard' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Hero Pure White Banner */}
            <div className="relative rounded-2xl p-6 overflow-hidden border border-slate-200 bg-white shadow-sm">
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 mb-3">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Enterprise Academic NLP Knowledge System</span>
                  </div>
                  <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">
                    NeuroTag Academic Intelligence Center
                  </h1>
                  <p className="text-xs text-slate-600 max-w-2xl mt-1.5 leading-relaxed">
                    Transform unstructured student lecture notes into weighted semantic taxonomies, interactive knowledge graphs, active-recall flashcards, and normalized MySQL schemas using Zero-Shot LLMs, KeyBERT embeddings, and LDA topic modeling.
                  </p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <button
                    onClick={() => setActiveTab('studio')}
                    className={`px-4 py-2.5 rounded-xl font-semibold text-xs flex items-center gap-2 transition-all ${currentTheme.accentBtn}`}
                  >
                    <Zap className="w-4 h-4" /> Open NLP Studio
                  </button>
                  <button
                    onClick={() => setActiveTab('graph')}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs flex items-center gap-2 border border-slate-200 transition-all"
                  >
                    <Network className="w-4 h-4 text-indigo-600" /> Explore Graph
                  </button>
                </div>
              </div>
            </div>

            {/* KPI Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Total Notes Indexed', value: kpiMetrics.totalNotes, sub: '+2 lectures this week', icon: BookOpen, color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-200' },
                { label: 'Unique Taxonomy Tags', value: kpiMetrics.uniqueTags, sub: `${kpiMetrics.totalTagAssignments} weighted relations`, icon: Tag, color: 'text-indigo-600', bg: 'bg-indigo-50 border-indigo-200' },
                { label: 'Avg NLP Confidence', value: kpiMetrics.avgConfidence, sub: 'Zero-Shot Gemini 3 Flash', icon: Award, color: 'text-amber-600', bg: 'bg-amber-50 border-amber-200' },
                { label: 'Active Subject Domains', value: kpiMetrics.activeDomains, sub: '100% syllabus coverage', icon: Layers, color: 'text-sky-600', bg: 'bg-sky-50 border-sky-200' }
              ].map((kpi, idx) => {
                const IconComp = kpi.icon;
                return (
                  <div
                    key={idx}
                    className={`p-5 rounded-2xl ${currentTheme.cardBg} flex items-start justify-between transition-all`}
                  >
                    <div>
                      <p className="text-xs text-slate-500 font-medium">{kpi.label}</p>
                      <p className="text-2xl font-extrabold mt-2 text-slate-900">{kpi.value}</p>
                      <p className="text-[11px] text-slate-500 mt-1">{kpi.sub}</p>
                    </div>
                    <div className={`p-3 rounded-xl border ${kpi.bg}`}>
                      <IconComp className={`w-5 h-5 ${kpi.color}`} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Middle Visual Breakdown: Top Tags & Subject Domains */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Tag Confidence & Frequency Cloud */}
              <div className={`lg:col-span-2 p-5 rounded-2xl ${currentTheme.cardBg}`}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-sm font-bold flex items-center gap-2 text-slate-900">
                      <BarChart3 className="w-4 h-4 text-emerald-600" /> Extracted Semantic Tag Taxonomy
                    </h2>
                    <p className="text-xs text-slate-500">Click any tag chip to filter student notes globally</p>
                  </div>
                  <span className="text-xs font-mono text-emerald-700 font-semibold">{allUniqueTags.length} verified concepts</span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {allUniqueTags.map(tag => {
                    const isSelected = selectedTagsFilter.includes(tag.name);
                    return (
                      <button
                        key={tag.name}
                        onClick={() => toggleTagFilter(tag.name)}
                        className={`group flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                          isSelected
                            ? 'bg-emerald-600 text-white font-bold border-emerald-700 shadow-sm'
                            : CATEGORY_STYLES[tag.category] || CATEGORY_STYLES['Core Concept']
                        }`}
                      >
                        <span>{tag.name}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${isSelected ? 'bg-emerald-700 text-white' : 'bg-white/80 text-slate-700 border border-slate-200'}`}>
                          {tag.avgConfidence}%
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Architecture Comparison Matrix */}
                <div className="mt-6 pt-5 border-t border-slate-200">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                    Interactive NLP Tagging Architecture Benchmark
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {[
                      {
                        name: 'Zero-Shot LLM (Gemini)',
                        speed: '~1.1s Latency',
                        strength: 'Infers broad hierarchical subjects & Bloom taxonomy without labeled training corpora.',
                        score: '96% Accuracy'
                      },
                      {
                        name: 'KeyBERT Cosine Hybrid',
                        speed: '~0.3s Latency',
                        strength: '768-d dense vector cosine similarity for exact technical n-grams & domain phrases.',
                        score: '91% Accuracy'
                      },
                      {
                        name: 'LDA Topic Modeling',
                        speed: '~0.2s Batch',
                        strength: 'Unsupervised Dirichlet distribution clustering across full-semester lecture corpora.',
                        score: '85% Coherence'
                      }
                    ].map((arch, i) => {
                      const isCurrent = selectedPipeline === arch.name;
                      return (
                        <div
                          key={i}
                          onClick={() => {
                            setSelectedPipeline(arch.name);
                            showToast(`Switched active NLP engine to ${arch.name}`, 'info');
                          }}
                          className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                            isCurrent
                              ? 'bg-emerald-50/70 border-emerald-400 shadow-xs'
                              : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-xs font-bold text-slate-900">{arch.name}</span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">
                              {arch.score}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-1.5 leading-relaxed">{arch.strength}</p>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-[10px] text-slate-500 font-mono">{arch.speed}</span>
                            <span className="text-[10px] text-emerald-700 font-semibold">
                              {isCurrent ? '● Active Engine' : 'Use Engine →'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Domain Distribution & Pipeline Activity */}
              <div className={`p-5 rounded-2xl ${currentTheme.cardBg} flex flex-col justify-between`}>
                <div>
                  <h2 className="text-sm font-bold flex items-center gap-2 text-slate-900 mb-1">
                    <PieChart className="w-4 h-4 text-indigo-600" /> Academic Domain Distribution
                  </h2>
                  <p className="text-xs text-slate-500 mb-4">Automated department classification</p>

                  <div className="space-y-3">
                    {domainDistribution.map((item, i) => (
                      <div key={i}>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="font-semibold text-slate-700">{item.domain}</span>
                          <span className="text-slate-500 font-mono">{item.count} notes ({item.percentage}%)</span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden border border-slate-200">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-indigo-500"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Live Pipeline Telemetry Log */}
                <div className="mt-6 pt-4 border-t border-slate-200">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5 flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-600" /> Real-Time NLP Telemetry Log
                  </h3>
                  <div className="space-y-2">
                    {pipelineLogs.slice(0, 3).map(log => (
                      <div key={log.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                        <div className="truncate pr-2">
                          <p className="font-semibold text-slate-800 truncate">{log.note}</p>
                          <p className="text-[10px] text-slate-500">{log.pipeline} • {log.latency} • {log.tokens || '410 tok'}</p>
                        </div>
                        <span className="shrink-0 text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
                          +{log.tagsFound} tags
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Indexed Notes Cards Grid */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-bold flex items-center gap-2 text-slate-900">
                  <FileText className="w-4 h-4 text-emerald-600" /> Categorized Student Lecture Repository
                </h2>
                <span className="text-xs text-slate-500">Showing {filteredNotes.length} of {notes.length} notes</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredNotes.map(note => (
                  <div
                    key={note.id}
                    onClick={() => {
                      setCurrentNote(note);
                      setActiveTab('studio');
                    }}
                    className={`p-5 rounded-2xl cursor-pointer transition-all ${currentTheme.cardBg}`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {note.courseCode}
                        </span>
                        <span className="text-xs text-slate-600 font-medium">{note.domain}</span>
                      </div>
                      <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 font-medium">
                        Bloom: {note.bloomLevel || 'Analyze'}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mb-1.5">{note.title}</h3>
                    <p className="text-xs text-slate-600 line-clamp-2 mb-3 leading-relaxed">{note.content}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {(note.tags || []).slice(0, 5).map((t, idx) => {
                        const name = typeof t === 'string' ? t : t.name;
                        const conf = typeof t === 'object' ? t.confidence : 88;
                        const cat = typeof t === 'object' ? t.category : 'Core Concept';
                        return (
                          <span
                            key={idx}
                            className={`text-[11px] px-2.5 py-0.5 rounded-lg border font-medium ${CATEGORY_STYLES[cat] || CATEGORY_STYLES['Core Concept']}`}
                          >
                            {name} <span className="opacity-75 font-mono">{conf}%</span>
                          </span>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* --- MODULE 2: ELABORATE NOTE STUDIO & DEEP NLP INSPECTOR --- */}
        {activeTab === 'studio' && (
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            
            {/* Left Column: Rich Academic Note Editor */}
            <div className="flex-1 flex flex-col h-full overflow-y-auto border-r border-slate-200 bg-white p-6 space-y-4">
              
              {/* Quick Academic Sample Templates Bar */}
              <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-slate-200">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-semibold text-slate-500 mr-1">Lecture Templates:</span>
                  {SAMPLE_TEMPLATES.map((tpl, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setCurrentNote(prev => ({
                          ...prev,
                          title: tpl.title,
                          courseCode: tpl.courseCode,
                          domain: tpl.domain,
                          content: tpl.content
                        }));
                        showToast(`Loaded "${tpl.label}" template`, 'info');
                      }}
                      className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 transition-colors font-medium"
                    >
                      + {tpl.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDeleteNote(currentNote.id)}
                    className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Delete Note"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleSaveNote}
                    disabled={isSaving}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold border border-slate-200 transition-all"
                  >
                    {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5 text-emerald-600" />}
                    <span>Save Note</span>
                  </button>
                </div>
              </div>

              {/* Note Metadata Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-1">Lecture / Note Title</label>
                  <input
                    type="text"
                    value={currentNote.title}
                    onChange={(e) => setCurrentNote({ ...currentNote, title: e.target.value })}
                    placeholder="Enter lecture title..."
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:bg-white focus:border-emerald-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-1">Course Code</label>
                  <input
                    type="text"
                    value={currentNote.courseCode || ''}
                    onChange={(e) => setCurrentNote({ ...currentNote, courseCode: e.target.value })}
                    placeholder="e.g. CS-302"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono font-semibold text-emerald-700 focus:bg-white focus:border-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* Action Bar: Run AI Pipeline & Synthesize Flashcards */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">AI Topic Tagging & Entity Extraction</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
                        {selectedPipeline}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Extracts weighted tags, domain hierarchy, Bloom cognitive level, and 3-bullet executive summary
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRunNLPPipeline}
                    disabled={isAnalyzing}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold text-xs disabled:opacity-50 transition-all ${currentTheme.accentBtn}`}
                  >
                    {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                    <span>{isAnalyzing ? 'Running NLP Pipeline...' : 'Analyze & Auto-Tag Note'}</span>
                  </button>
                  <button
                    onClick={handleSynthesizeStudyMaterial}
                    disabled={isGeneratingStudy}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-semibold text-xs transition-all"
                    title="Generate Active Recall Flashcards & Quiz from this note"
                  >
                    {isGeneratingStudy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <GraduationCap className="w-3.5 h-3.5" />}
                    <span>Synthesize Flashcards</span>
                  </button>
                </div>
              </div>

              {/* Editor Textarea */}
              <div className="flex-1 flex flex-col min-h-[250px]">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold">
                    Raw Lecture Note Content ({currentNote.content?.split(/\s+/).filter(Boolean).length || 0} words)
                  </label>
                  <button
                    onClick={() => setHighlightEntities(!highlightEntities)}
                    className={`text-xs flex items-center gap-1 px-2.5 py-0.5 rounded-lg border font-medium ${
                      highlightEntities
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-slate-100 text-slate-500 border-slate-200'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" /> Inline NER Highlighter: {highlightEntities ? 'ON' : 'OFF'}
                  </button>
                </div>
                <textarea
                  value={currentNote.content}
                  onChange={(e) => setCurrentNote({ ...currentNote, content: e.target.value })}
                  placeholder="Paste or type raw lecture notes, code snippets, or textbook excerpts here..."
                  className="w-full flex-1 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-slate-900 text-sm leading-relaxed font-mono focus:bg-white focus:border-emerald-500 outline-none resize-none"
                />
              </div>

              {/* Live Named Entity Highlight Preview Box */}
              {highlightEntities && (currentNote.entities || []).length > 0 && (
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Code className="w-3.5 h-3.5 text-emerald-600" /> Live Named Entity Recognition (NER) Annotated View
                    </span>
                    <span className="text-[11px] text-emerald-700 font-mono font-semibold">{(currentNote.entities || []).length} entities highlighted</span>
                  </div>
                  {renderHighlightedContent(currentNote.content, currentNote.entities)}
                </div>
              )}
            </div>

            {/* Right Column: Deep NLP Inspector Panel */}
            <div className="w-full lg:w-96 xl:w-[430px] shrink-0 h-full overflow-y-auto p-6 space-y-5 bg-slate-50/70">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div>
                  <h2 className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Sliders className="w-4 h-4 text-emerald-600" /> Deep NLP Inspector
                  </h2>
                  <p className="text-[11px] text-slate-500">Semantic classification & confidence weights</p>
                </div>
                <span className="text-[11px] px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
                  {currentNote.difficulty || 'Intermediate'}
                </span>
              </div>

              {/* Domain & Bloom Classification Card */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-[10px] uppercase text-slate-400 font-semibold">Primary Domain</span>
                  <p className="text-xs font-bold text-slate-900 mt-0.5 truncate">{currentNote.domain || 'Unassigned'}</p>
                  <p className="text-[11px] text-slate-500 truncate">{currentNote.subDomain || 'General'}</p>
                </div>
                <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-[10px] uppercase text-slate-400 font-semibold">Bloom's Taxonomy</span>
                  <p className="text-xs font-bold text-indigo-700 mt-0.5">{currentNote.bloomLevel || 'Analyze'}</p>
                  <p className="text-[11px] text-slate-500">Cognitive Level</p>
                </div>
              </div>

              {/* Confidence Threshold Slider */}
              <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-2 shadow-2xs">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800">Confidence Threshold Filter</span>
                  <span className="font-mono font-bold text-emerald-700">&ge; {confidenceThreshold}%</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="95"
                  step="5"
                  value={confidenceThreshold}
                  onChange={(e) => setConfidenceThreshold(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <p className="text-[11px] text-slate-500">
                  Filtering out low-salience tags below {confidenceThreshold}% cosine/LLM confidence.
                </p>
              </div>

              {/* Extracted Tags with Confidence Bars */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Extracted Topic Tags ({(currentNote.tags || []).filter(t => (t.confidence || 85) >= confidenceThreshold).length})
                  </h3>
                  <span className="text-[10px] text-slate-400 font-medium">Category & Weight</span>
                </div>

                <div className="space-y-2">
                  {(currentNote.tags || [])
                    .filter(t => (typeof t === 'object' ? t.confidence : 85) >= confidenceThreshold)
                    .map((tag, idx) => {
                      const name = typeof tag === 'string' ? tag : tag.name;
                      const conf = typeof tag === 'object' ? tag.confidence : 85;
                      const cat = typeof tag === 'object' ? tag.category : 'Core Concept';
                      return (
                        <div key={idx} className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <div className="flex items-center gap-2 truncate">
                              <span className="text-xs font-bold text-slate-900 truncate">{name}</span>
                              <span className={`text-[10px] px-2 py-0.5 rounded-md border font-medium ${CATEGORY_STYLES[cat] || CATEGORY_STYLES['Core Concept']}`}>
                                {cat}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-xs font-mono font-bold text-emerald-700">{conf}%</span>
                              <button
                                onClick={() => handleRemoveTagFromCurrent(name)}
                                className="text-slate-400 hover:text-rose-600"
                                title="Remove Tag"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                          <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-indigo-500 transition-all duration-500"
                              style={{ width: `${conf}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                </div>

                {/* Manual Tag Override Form */}
                <form onSubmit={handleAddCustomTag} className="pt-2 flex gap-2">
                  <input
                    type="text"
                    value={customTagInput}
                    onChange={(e) => setCustomTagInput(e.target.value)}
                    placeholder="Add manual tag..."
                    className="flex-1 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 placeholder-slate-400 outline-none focus:border-emerald-500"
                  />
                  <select
                    value={customTagCategory}
                    onChange={(e) => setCustomTagCategory(e.target.value)}
                    className="px-2 py-1.5 rounded-xl bg-white border border-slate-200 text-xs text-slate-700 outline-none"
                  >
                    <option value="Core Concept">Core Concept</option>
                    <option value="Tool/Tech">Tool/Tech</option>
                    <option value="Prerequisite">Prerequisite</option>
                    <option value="Action Item">Action Item</option>
                  </select>
                  <button
                    type="submit"
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 ${currentTheme.accentBtn}`}
                  >
                    Add
                  </button>
                </form>
              </div>

              {/* AI Executive Summary */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-2xs">
                <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-700 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Automated Executive Summary
                </h3>
                {(currentNote.summary || []).length > 0 ? (
                  <ul className="space-y-1.5 text-xs text-slate-700 list-disc list-inside">
                    {currentNote.summary.map((point, idx) => (
                      <li key={idx} className="leading-relaxed">{point}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-slate-400 italic">
                    Click "Analyze & Auto-Tag Note" to synthesize key takeaways.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* --- MODULE 3: INTERACTIVE KNOWLEDGE GRAPH & TAXONOMY EXPLORER --- */}
        {activeTab === 'graph' && (
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden p-6 gap-6">
            {/* SVG Interactive Force/Radial Graph */}
            <div className={`flex-1 rounded-2xl ${currentTheme.cardBg} flex flex-col overflow-hidden relative`}>
              <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Network className="w-4 h-4 text-emerald-600" /> Semantic Note-to-Tag Knowledge Graph
                  </h2>
                  <p className="text-xs text-slate-500">
                    Inner ring: Student Notes • Outer ring: Extracted Concept Tags. Click any node to inspect connections.
                  </p>
                </div>

                {/* Zoom & Domain Filter Controls */}
                <div className="flex items-center gap-2">
                  <select
                    value={graphDomainFilter}
                    onChange={(e) => setGraphDomainFilter(e.target.value)}
                    className="px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 outline-none"
                  >
                    <option value="All">All Domains</option>
                    {domainDistribution.map(d => (
                      <option key={d.domain} value={d.domain}>{d.domain}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => setGraphZoom(z => Math.min(1.4, +(z + 0.15).toFixed(2)))}
                    className="p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-900"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setGraphZoom(z => Math.max(0.7, +(z - 0.15).toFixed(2)))}
                    className="p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-900"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setGraphZoom(1);
                      setGraphDomainFilter('All');
                      setSelectedGraphNode(null);
                    }}
                    className="p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-900"
                    title="Reset View"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex-1 flex items-center justify-center overflow-hidden bg-slate-50/50">
                <svg
                  viewBox="0 0 840 520"
                  className="w-full h-full max-h-[520px] transition-transform duration-300"
                  style={{ transform: `scale(${graphZoom})` }}
                >
                  <defs>
                    <radialGradient id="cleanGlow" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#10b981" stopOpacity="0.12" />
                      <stop offset="60%" stopColor="#6366f1" stopOpacity="0.05" />
                      <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
                    </radialGradient>
                  </defs>

                  {/* Center Hub Subtle Aura */}
                  <circle cx="420" cy="260" r="210" fill="url(#cleanGlow)" />

                  {/* Edges */}
                  {graphData.links.map((link, idx) => {
                    const sourceNode = graphData.nodes.find(n => n.id === link.source);
                    const targetNode = graphData.nodes.find(n => n.id === link.target);
                    if (!sourceNode || !targetNode) return null;

                    const isHighlighted =
                      selectedGraphNode &&
                      (selectedGraphNode.id === sourceNode.id || selectedGraphNode.id === targetNode.id);

                    return (
                      <line
                        key={idx}
                        x1={sourceNode.x}
                        y1={sourceNode.y}
                        x2={targetNode.x}
                        y2={targetNode.y}
                        stroke={isHighlighted ? '#059669' : '#cbd5e1'}
                        strokeWidth={isHighlighted ? 2.6 : 1.4}
                        strokeOpacity={isHighlighted ? 1 : 0.7}
                      />
                    );
                  })}

                  {/* Nodes */}
                  {graphData.nodes.map(node => {
                    const isSelected = selectedGraphNode?.id === node.id;
                    const isNote = node.type === 'note';
                    return (
                      <g
                        key={node.id}
                        onClick={() => setSelectedGraphNode(node)}
                        className="cursor-pointer group"
                      >
                        <circle
                          cx={node.x}
                          cy={node.y}
                          r={isNote ? 18 : 13}
                          fill={isNote ? '#059669' : '#4f46e5'}
                          stroke={isSelected ? '#0f172a' : '#ffffff'}
                          strokeWidth={isSelected ? 3.5 : 2}
                        />
                        <text
                          x={node.x}
                          y={node.y + (isNote ? 30 : 24)}
                          textAnchor="middle"
                          fill={isSelected ? '#059669' : '#1e293b'}
                          fontSize={isNote ? '11' : '10'}
                          fontWeight={isSelected || isNote ? '700' : '600'}
                        >
                          {node.label}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>

            {/* Right Inspector: Selected Node & Domain Hierarchy Tree */}
            <div className="w-full lg:w-80 shrink-0 flex flex-col gap-4 overflow-y-auto">
              {selectedGraphNode ? (
                <div className={`p-5 rounded-2xl ${currentTheme.cardBg} space-y-3`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {selectedGraphNode.type === 'note' ? 'Student Note Node' : 'Taxonomy Tag Node'}
                    </span>
                    <button
                      onClick={() => setSelectedGraphNode(null)}
                      className="text-slate-400 hover:text-slate-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">
                    {selectedGraphNode.fullTitle || selectedGraphNode.label}
                  </h3>
                  {selectedGraphNode.type === 'tag' ? (
                    <div className="space-y-2 text-xs text-slate-600">
                      <p>Category: <span className="text-indigo-700 font-semibold">{selectedGraphNode.category}</span></p>
                      <p>Avg Confidence: <span className="text-emerald-700 font-mono font-bold">{selectedGraphNode.confidence}%</span></p>
                      <button
                        onClick={() => {
                          toggleTagFilter(selectedGraphNode.label);
                          setActiveTab('dashboard');
                        }}
                        className={`w-full mt-2 py-2 rounded-xl font-semibold text-xs ${currentTheme.accentBtn}`}
                      >
                        Filter Notes by "{selectedGraphNode.label}"
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2 text-xs text-slate-600">
                      <p>Academic Domain: <span className="text-indigo-700 font-semibold">{selectedGraphNode.domain}</span></p>
                      <button
                        onClick={() => {
                          const found = notes.find(n => n.id === selectedGraphNode.rawId);
                          if (found) {
                            setCurrentNote(found);
                            setActiveTab('studio');
                          }
                        }}
                        className={`w-full mt-2 py-2 rounded-xl font-semibold text-xs ${currentTheme.accentBtn}`}
                      >
                        Open Note in Studio
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className={`p-4 rounded-2xl ${currentTheme.cardBg} text-xs text-slate-500`}>
                  Click any node in the Knowledge Graph to inspect its semantic relationships or open the lecture note.
                </div>
              )}

              {/* Hierarchical Domain Taxonomy Tree */}
              <div className={`flex-1 p-5 rounded-2xl ${currentTheme.cardBg} overflow-y-auto`}>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3 flex items-center gap-2">
                  <FolderTree className="w-4 h-4 text-emerald-600" /> Academic Domain Hierarchy
                </h3>
                <div className="space-y-3">
                  {domainDistribution.map(dom => (
                    <div key={dom.domain} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-800 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                        <span>{dom.domain}</span>
                        <span className="text-[10px] text-emerald-700 font-mono">{dom.count} notes</span>
                      </div>
                      <div className="pl-3 border-l-2 border-slate-200 space-y-1">
                        {notes
                          .filter(n => n.domain === dom.domain)
                          .map(n => (
                            <div
                              key={n.id}
                              onClick={() => {
                                setCurrentNote(n);
                                setActiveTab('studio');
                              }}
                              className="text-xs text-slate-600 hover:text-emerald-700 font-medium cursor-pointer py-1 truncate"
                            >
                              • {n.title}
                            </div>
                          ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* --- MODULE 4: AI STUDY ASSISTANT & FLASHCARD / QUIZ SYNTHESIZER --- */}
        {activeTab === 'study' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <h1 className="text-xl font-bold flex items-center gap-2 text-slate-900">
                  <GraduationCap className="w-6 h-6 text-emerald-600" /> Active Recall Study Synthesizer
                </h1>
                <p className="text-xs text-slate-500">
                  Interactive flip flashcards and concept check quizzes synthesized from your tagged lecture notes
                </p>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={selectedStudyTag}
                  onChange={(e) => setSelectedStudyTag(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-700 outline-none shadow-2xs"
                >
                  <option value="All">All Topic Tags ({flashcards.length})</option>
                  {Array.from(new Set(flashcards.map(f => f.tag))).map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
                <button
                  onClick={handleSynthesizeStudyMaterial}
                  disabled={isGeneratingStudy}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold ${currentTheme.accentBtn}`}
                >
                  {isGeneratingStudy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>Synthesize from Current Note</span>
                </button>
              </div>
            </div>

            {/* Interactive Flip Flashcards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {flashcards
                .filter(fc => selectedStudyTag === 'All' || fc.tag === selectedStudyTag)
                .map(card => {
                  const isFlipped = !!flippedCards[card.id];
                  return (
                    <div
                      key={card.id}
                      onClick={() => setFlippedCards(prev => ({ ...prev, [card.id]: !prev[card.id] }))}
                      className={`p-6 rounded-2xl border cursor-pointer transition-all min-h-[185px] flex flex-col justify-between ${
                        isFlipped
                          ? 'bg-emerald-50/70 border-emerald-300 shadow-md'
                          : currentTheme.cardBg
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
                          {card.tag}
                        </span>
                        <span className="text-[11px] text-slate-500 flex items-center gap-1 font-medium">
                          <FlipHorizontal className="w-3.5 h-3.5 text-indigo-600" /> {isFlipped ? 'Answer (Click to flip)' : 'Question (Click to flip)'}
                        </span>
                      </div>

                      <div className="my-4">
                        {isFlipped ? (
                          <p className="text-sm text-emerald-950 font-medium leading-relaxed">{card.answer}</p>
                        ) : (
                          <p className="text-sm font-bold text-slate-900 leading-relaxed">{card.question}</p>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>Difficulty: <strong className="text-slate-800">{card.difficulty}</strong></span>
                        <span className="text-indigo-600 font-semibold">Active Recall Card</span>
                      </div>
                    </div>
                  );
                })}
            </div>

            {/* AI Synthesized Multiple Choice Quiz Section */}
            {quizQuestions.length > 0 && (
              <div className={`p-6 rounded-2xl ${currentTheme.cardBg} space-y-4`}>
                <h2 className="text-base font-bold flex items-center gap-2 text-slate-900">
                  <HelpCircle className="w-5 h-5 text-indigo-600" /> AI-Generated Concept Check Quiz
                </h2>
                <div className="space-y-4">
                  {quizQuestions.map((q, qIdx) => (
                    <div key={qIdx} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                      <p className="text-sm font-bold text-slate-900">{qIdx + 1}. {q.question}</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {(q.options || []).map((opt, oIdx) => {
                          const selected = quizAnswers[qIdx] === oIdx;
                          const isCorrect = q.correctIndex === oIdx;
                          const showResult = quizAnswers[qIdx] !== undefined;
                          return (
                            <button
                              key={oIdx}
                              onClick={() => setQuizAnswers(prev => ({ ...prev, [qIdx]: oIdx }))}
                              className={`text-left p-3 rounded-xl text-xs border transition-all ${
                                !showResult
                                  ? 'bg-white border-slate-200 hover:border-emerald-400 text-slate-700'
                                  : isCorrect
                                  ? 'bg-emerald-50 border-emerald-400 text-emerald-900 font-bold'
                                  : selected
                                  ? 'bg-rose-50 border-rose-300 text-rose-800'
                                  : 'bg-white/60 border-slate-200 text-slate-400'
                              }`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>
                      {quizAnswers[qIdx] !== undefined && (
                        <p className="text-xs text-slate-700 bg-white p-3 rounded-xl border border-slate-200">
                          <strong className="text-emerald-700">Explanation:</strong> {q.explanation}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* --- MODULE 5: RELATIONAL SQL / JSON / CSV SCHEMA EXPORTER --- */}
        {activeTab === 'export' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold flex items-center gap-2 text-slate-900">
                  <Database className="w-6 h-6 text-emerald-600" /> Relational Database & JSON Schema Exporter
                </h1>
                <p className="text-xs text-slate-500">
                  Export your categorized student notes and many-to-many tag relationships as production-ready MySQL DDL/DML, JSON, or CSV
                </p>
              </div>
              <div className="flex items-center gap-2">
                {['sql', 'json', 'csv'].map(fmt => (
                  <button
                    key={fmt}
                    onClick={() => setExportFormat(fmt)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase border transition-all ${
                      exportFormat === fmt
                        ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                        : 'bg-white text-slate-600 border-slate-200 hover:text-slate-900'
                    }`}
                  >
                    {fmt === 'sql' ? 'MySQL Schema' : fmt}
                  </button>
                ))}
                <button
                  onClick={handleCopyExport}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold ${currentTheme.accentBtn}`}
                >
                  {copiedExport ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedExport ? 'Copied!' : 'Copy Code'}</span>
                </button>
              </div>
            </div>

            {/* Entity-Relationship Diagram Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className={`p-4 rounded-2xl ${currentTheme.cardBg}`}>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">Table 1 • Primary Entity</span>
                <h3 className="text-sm font-bold text-slate-900 mt-2">notes</h3>
                <p className="text-xs text-slate-600 mt-1">Stores `note_id` (PK), `title`, `course_code`, `academic_domain`, `bloom_taxonomy`, and `raw_content`.</p>
              </div>
              <div className={`p-4 rounded-2xl ${currentTheme.cardBg}`}>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold">Table 2 • Junction (M:N)</span>
                <h3 className="text-sm font-bold text-slate-900 mt-2">note_tags</h3>
                <p className="text-xs text-slate-600 mt-1">Resolves Many-to-Many mapping with composite PK (`note_id`, `tag_name`) + `confidence_score`.</p>
              </div>
              <div className={`p-4 rounded-2xl ${currentTheme.cardBg}`}>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 font-semibold">Table 3 • Master Taxonomy</span>
                <h3 className="text-sm font-bold text-slate-900 mt-2">tags</h3>
                <p className="text-xs text-slate-600 mt-1">Normalized dictionary of unique `tag_name` entries and their semantic `tag_category`.</p>
              </div>
            </div>

            {/* Code Output Viewer */}
            <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-sm">
              <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600">
                <span className="font-mono font-semibold text-slate-800">neurotag_export.{exportFormat}</span>
                <span>{notes.length} notes • {allUniqueTags.length} unique tags</span>
              </div>
              <pre className="p-5 text-xs font-mono text-slate-800 bg-slate-50/40 overflow-x-auto max-h-[420px] leading-relaxed">
                {generatedExportCode}
              </pre>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}