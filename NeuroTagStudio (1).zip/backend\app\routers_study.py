import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from .database import get_db
from .models import Note
from .schemas import StudyMaterialResponse, FlashcardItem, QuizOptionItem

router = APIRouter(prefix="/study", tags=["Active Recall & Study"])

@router.post("/synthesize/{note_id}", response_model=StudyMaterialResponse)
async def synthesize_study_material(note_id: str, db: AsyncSession = Depends(get_db)):
    """
    Synthesizes active recall flip flashcards and a multiple choice quiz from note concepts.
    """
    stmt = select(Note).options(selectinload(Note.note_tags)).where(Note.note_id == note_id)
    res = await db.execute(stmt)
    note = res.scalar_one_or_none()

    if not note:
        raise HTTPException(status_code=404, detail="Note not found")

    tags = [nt.tag_name for nt in note.note_tags]
    primary_tag = tags[0] if tags else (note.academic_domain or "Core Concept")

    # Generate Flashcard
    summary_text = " ".join(note.summary) if note.summary else note.raw_content[:200]
    flashcards = [
        FlashcardItem(
            id=f"fc-{uuid.uuid4().hex[:8]}",
            tag=primary_tag,
            question=f"What are the central operational concepts defined in '{note.title}'?",
            answer=summary_text,
            difficulty=note.difficulty or "Intermediate"
        )
    ]

    # Generate Multiple Choice Quiz Question
    quiz = [
        QuizOptionItem(
            question=f"Which domain hierarchy does '{note.title}' address?",
            options=[
                f"{note.academic_domain} ({note.sub_domain})",
                "Classical Mechanical Physics",
                "Organic Synthesis Chemistry",
                "Civil Structural Mechanics"
            ],
            correctIndex=0,
            explanation=f"The lecture specifically covers {note.academic_domain} under Bloom's cognitive level of {note.bloom_taxonomy}."
        )
    ]

    return StudyMaterialResponse(flashcards=flashcards, quiz=quiz)
