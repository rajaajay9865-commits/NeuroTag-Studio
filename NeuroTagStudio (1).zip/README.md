# NeuroTag Studio - Full Stack Academic NLP System

An academic knowledge workbench that performs automatic topic tagging, Named Entity Recognition (NER), knowledge graph mapping, active recall flashcards, and relational MySQL schema exports on student lecture notes.

---

## Project Structure

```text
├── index.html                  # Complete, zero-dependency Frontend Web Application (React 18 + Tailwind + Lucide)
├── neurotag_studio_academic_nlp_knowledge_system.tsx # Original React TypeScript Module
└── backend/                    # Python FastAPI Production-Ready Backend
    ├── requirements.txt        # Backend dependencies (FastAPI, SQLAlchemy 2.0, Uvicorn, httpx, etc.)
    ├── .env.example            # Environment variables template (SQLite or MySQL & Gemini API)
    └── app/
        ├── config.py           # Application settings & database connection string
        ├── database.py         # Asynchronous SQLAlchemy engine & session maker
        ├── models.py           # Relational 3-table models (notes, tags, note_tags)
        ├── schemas.py          # Pydantic data validation schemas
        ├── nlp_service.py      # LLM / Gemini client + local heuristic fallback engine
        ├── routers_notes.py    # /api/v1/notes and /api/v1/notes/analyze endpoints
        ├── routers_graph.py    # /api/v1/graph (2D radial node-link coordinates)
        ├── routers_study.py    # /api/v1/study/synthesize (flashcards & quiz generator)
        └── main.py             # FastAPI entrypoint with CORS & auto-table creation
```

---

## 1. Running the Frontend Immediately (No Build Step Required)

1. Simply double-click **`index.html`** or open it in any modern web browser (Google Chrome, Microsoft Edge, Brave, Firefox).
2. It runs immediately with local storage persistence and its built-in NLP engine.
3. If the backend is running on `http://localhost:8000`, the frontend automatically sends live analysis requests to the FastAPI backend!

---

## 2. Running the Python FastAPI Backend

### Prerequisites
- Python 3.10+ installed.

### Setup Steps
```bash
# 1. Navigate to the backend folder
cd backend

# 2. (Optional) Create and activate a virtual environment
python -m venv venv
# On Windows:
venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) Configure .env
copy .env.example .env
# Edit .env if you wish to use MySQL or supply a GEMINI_API_KEY.
# Default runs with local asynchronous SQLite automatically!

# 5. Start the API Server
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Interactive API Documentation
Once started, access the interactive Swagger documentation at:
- **Swagger UI:** `http://localhost:8000/docs`
- **ReDoc:** `http://localhost:8000/redoc`

---

## 3. Database Schema (MySQL & SQLite)

The platform implements a normalized **Many-to-Many** relational model:
1. **`notes`**: `note_id` (PK), `title`, `course_code`, `academic_domain`, `bloom_taxonomy`, `raw_content`, `summary`, `entities`.
2. **`tags`**: `tag_id` (PK Auto-increment), `tag_name` (Unique), `tag_category`, `taxonomy_path`.
3. **`note_tags`**: `note_id` (FK), `tag_name` (FK), `confidence_score`.
