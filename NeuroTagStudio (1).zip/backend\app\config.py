import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "NeuroTag Studio Academic NLP API"
    APP_VERSION: str = "1.0.0"
    API_PREFIX: str = "/api/v1"
    
    # Database Configuration (Defaults to local SQLite for instant out-of-the-box run, easily switched to MySQL)
    # For MySQL: mysql+aiomysql://root:password@localhost:3306/neurotag_academic_db
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./neurotag.db")
    
    # Gemini / LLM API Key (optional - built-in zero-shot fallback activates if not set)
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    
    # Server Host & Port
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    class Config:
        env_file = ".env"

settings = Settings()
