import datetime
from sqlalchemy import Column, String, Text, Integer, Float, ForeignKey, DateTime, JSON
from sqlalchemy.orm import relationship
from .database import Base

class Note(Base):
    __tablename__ = "notes"

    note_id = Column(String(64), primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    course_code = Column(String(32), index=True)
    academic_domain = Column(String(100), index=True)
    sub_domain = Column(String(100))
    bloom_taxonomy = Column(String(50))
    difficulty = Column(String(50), default="Intermediate")
    nlp_pipeline = Column(String(100), default="Zero-Shot LLM (Gemini)")
    raw_content = Column(Text, nullable=False)
    summary = Column(JSON, default=list)
    entities = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    # Relationship to Junction Table
    note_tags = relationship("NoteTag", back_populates="note", cascade="all, delete-orphan")


class Tag(Base):
    __tablename__ = "tags"

    tag_id = Column(Integer, primary_key=True, autoincrement=True)
    tag_name = Column(String(100), unique=True, nullable=False, index=True)
    tag_category = Column(String(50), default="Core Concept")
    taxonomy_path = Column(String(255), nullable=True)

    # Relationship to Junction Table
    note_tags = relationship("NoteTag", back_populates="tag")


class NoteTag(Base):
    __tablename__ = "note_tags"

    note_id = Column(String(64), ForeignKey("notes.note_id", ondelete="CASCADE"), primary_key=True)
    tag_name = Column(String(100), ForeignKey("tags.tag_name", ondelete="CASCADE"), primary_key=True)
    confidence_score = Column(Float, nullable=False)

    # Relationships
    note = relationship("Note", back_populates="note_tags")
    tag = relationship("Tag", back_populates="note_tags")
